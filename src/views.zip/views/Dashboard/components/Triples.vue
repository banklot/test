<script setup lang="ts">

</script>

<template>
  <div class="games">
    <div class="bgImgCenter" style="background-image: url(/images/products/zulia.png);"></div>
    <div class="bgImgCenter" style="background-image: url(/images/products/caracas.png);"></div>
    <div class="bgImgCenter" style="background-image: url(/images/products/zamorano.png);"></div>
    <div class="bgImgCenter" style="background-image: url(/images/products/caliente.png);"></div>
  </div>

</template>
