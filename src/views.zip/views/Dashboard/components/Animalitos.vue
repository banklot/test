<script setup lang="ts">

</script>

<template>
  <div class="games">
    <div class="bgImgCenter" style="background-image: url(/images/products/la-granjita.png);"></div>
    <div class="bgImgCenter" style="background-image: url(/images/products/selva-plus.png);"></div>
    <div class="bgImgCenter" style="background-image: url(/images/products/jungla.png);"></div>
  </div>

</template>

<style scoped lang="scss">

</style>