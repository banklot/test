<script setup lang="ts">

</script>

<template>
  <div class="games">
    <div class="bgImgCenter" style="background-image: url(/images/products/astrolotto.png);"></div>
    <div class="bgImgCenter" style="background-image: url(/images/products/lotto-livery.png);"></div>
  </div>

</template>

<style scoped lang="scss">

</style>