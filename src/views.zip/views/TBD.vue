<script setup lang="ts">

</script>

<template>
  <div class="card">
    <div class="windowTitle">TBD</div>

  </div>
</template>

<style scoped lang="scss">

</style>
