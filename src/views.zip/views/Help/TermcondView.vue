<script setup lang="ts">
import ScrollPanel from "primevue/scrollpanel";

</script>

<template>

  <div class="card" id="cardoverflow">

    <div class="windowTitle">Términos y Condiciones</div>

    <div class=" text-justify flex justify-content-center mt-4" >
      <ScrollPanel class="scrollPanel" id="scroll" >
        <center>
          <h5><b> REPÚBLICA BOLIVARIANA DE VENEZUELA </b></h5>
          <h5>
            <b>
              INSTITUTO RENTA DE BENEFICENCIA PÚBLICA Y DE ASISTENCIA SOCIAL DEL
              ESTADO ZULIA, "LOTERÍA DEL ZULIA" (IOBPAS)
            </b>
          </h5>
          <h5><b>CARACAS, 04 DE OCTUBRE DE 2022</b></h5>
          <h5><b> DICTA </b></h5>
          <h5><b>TÉRMINOS Y CONDICIONES DE USO PARA EL APOSTADOR</b></h5>
        </center>

        La Lotería del Zulia en aras de ofrecer a nuestras preciada clientela un
        servicio de excelente calidad que cumpla con los estándares del mercado y
        que garantice un servicio de primera a nuestro público Apostador,
        establece los siguientes <b>TÉRMINOS Y CONDICIONES DE USO</b> de nuestra
        plataforma online, que no solo serán imprescindibles para evitar posibles
        sanciones, sino también que son la cara para proteger el futuro de las
        posibles reclamaciones y dudas que pudieren surgir a nuestros apostadores
        sobre el acceso a los contenidos y servicios de nuestra plataforma.
        <br/><br/>

        Por lo que recomendamos, a todos los Apostadores, leer atentamente la
        totalidad de estos términos y condiciones, siendo los mismos vinculantes
        para el uso del sitio web de la Lotería del Zulia. En el caso que
        cualquier visitante se encuentre en desacuerdo con las condiciones que se
        deriven de los mismo, es preciso abstenerse de continuar con el uso de la
        página, pues el registro y uso implican la aceptación contractual,
        integral y sin reservas de estos términos y condiciones, sus
        modificaciones y actualizaciones.<br/>
        <br/>
        <center>
          <h5><b>CAPÍTULO I DE LA ACEPTACIÓN DE LAS CONDICIONES DE USO </b></h5>
        </center>
        <b>ARTÍCULO 1:</b>
        El presente documento jurídico, establece los términos y condiciones
        generales de uso de nuestra plataforma, que
        <b
        >EL INSTITUCIONES OFICIALES DE BENEFICENCIA PÚBLICA Y ASISTENCIA SOCIAL
          (LOTERIA DEL ZULIA) IOBPAS,</b
        >
        como entes creados por el Estado para el ejercicio de la actividad de
        juegos de lotería, que le ha sido reservada de conformidad a lo
        establecido en la ley nacional de lotería, y que a través de
        <b>LA OPERADORA ZUAZAR 3000 C.A. J-502248676,</b> debidamente inscrita
        ante el Registro Mercantil Tercero de la Circunscripción Judicial del
        Estado Zulia, en fecha diecisiete (17) de mayo de 2022, bajo el N.º 12,
        Tomo 33-A, está autorizada por la Comisión Nacional de Lotería bajo los
        números de licencia N°07-0-000031-2022 y bajo N°07-0-000030-2022, de fecha
        18 de noviembre de 2022, se establecen los siguientes términos y
        condiciones de conformidad a las normas previstas en las leyes y
        providencia de la República Bolivariana de Venezuela.<br/>
        <br/><b>ARTÍCULO 2:</b>
        El uso de nuestra plataforma, así como la compra de nuestros productos
        implica que usted ha leído detenidamente y aceptado los Términos y
        Condiciones de uso de nuestro sitio web, y todas las implicaciones que de
        él se deriven.
        <br/>
        <br/>
        <center>
          <h5><b>CAPÍTULO II DE LOS USOS DE LOS TÉRMINOS</b></h5>
        </center>

        <b>ARTÍCULO 3:</b>
        A los efectos del presente, se establecen los siguientes Términos y
        Condiciones a los apostadores que realicen su registro a través de nuestro
        portal web y puedan realizar sus jugadas, los cuales se describen a
        continuación: <br/>
        <br/>1.APOSTADOR: Se define como apostador a la persona que paga el
        derecho a participar en el juego de lotería, ofreciéndole a cambio un
        premio en dinero y/o en especie, que ganara solo si acierta los resultados
        de los juegos. Quien previamente debe realizar un registro en nuestra
        plataforma digital, debiendo ser mayor de edad, civilmente hábil.<br/>
        <br/>2. PLATAFORMA: Es una herramienta de carácter digital que tiene dos
        características principales: a) Que a través de ella se ofrecen el sistema
        de venta de lotería online en el mercado digital. b) Facilitan la
        interacción, mediante la prestación del servicio, del apostador con la
        operadora, a través del acceso de la web, desde su equipo móvil o un PC
        conectados al Internet. Además de dar más control de los contenidos y
        productos que ofrece la lotería, con un sistema de venta más personalizado
        y seguro para obtener sus ganancias.<br/>
        <br/>3. REGISTRO: Paso necesario al ingresar en la PLATAFORMA, donde el
        APOSTADOR debe suministrar, todos sus datos de identificación y una
        contraseña, además de los datos de su número telefónico para recibir a
        través de mensaje de SMS la verificación del registro.<br/>
        <br/>4. CONTRASEÑA: es un conjunto de caracteres utilizados para acceder
        a información reservada en el sitio web de la lotería, desde computador o
        a un dispositivo móvil.<br/>
        <br/>5. WEB: Es un espacio online que ofrece la Lotería del Zulia a
        través de la operadora, donde el público apostador puede realizar sus
        apuestas, en particular a la que se puede acceder desde un buscador en
        internet. <br/>
        <br/>6. CÓDIGO DE VERIFICACIÓN: Es un elemento de seguridad que le
        permite a la operadora validar de forma ilimitada durante 60 segundo, la
        identidad de la persona, así como también para recuperar contraseñas de
        acceso, y verificación de pago móvil, para poder realizar sus apuestas.
        <br/>
        <br/>7. PAGO MOVIL: Se refiere al conjunto de servicios que permiten
        realizar transacciones financieras a través de teléfonos móviles. Incluye
        tanto el pago de determinados productos y servicios como la transferencia
        de dinero tanto de persona naturales como jurídica. Esta modalidad de pago
        le permite a LOS APOSTADORES, recargar su saldo a la plataforma, para
        realizar la compra de los tickets.<br/>
        <br/>8. FONDOS PARA JUGAR: Es la sección de la plataforma donde se ve
        reflejado el saldo, recargado desde el pago móvil afiliado a la cuenta del
        titular, para realizar las apuestas, Una vez recargado el mismo no podrá
        retirarlo, sólo se podrás retirar las ganancias obtenidas. <br/>
        <br/>9. CALCULADORA: Se trata de una sección que ofrece la plataforma que
        cumple con las mismas funciones de los dispositivos digitales, que le
        permiten al apostador calcular el monto de sus jugadas a la tasa del día,
        para poder así realizar su pago móvil desde su cuenta autorizada.<br/>
        <br/>10. CODIGO DE VALIDACIÓN O QR: Es un código alfanumérico, único e
        irrepetible, generado por el Sistema de Lotería online de la operadora y
        aceptado por INSTITUTO RENTA DE BENEFICENCIA PÚBLICA Y DE ASISTENCIA
        SOCIAL DEL ESTADO ZULIA, (LOTERIA DEL ZULIA); lo que permite una posterior
        validación de la legalidad de esta, ante los organismos competentes.<br/>
        <br/>11. REDES SOCIALES: Son estructuras formadas en Internet por
        personas u organizaciones que se conectan a partir de intereses o valores
        comunes. A través de ellas, se crean relaciones entre individuos o
        empresas de forma rápida, sin jerarquía o límites físicos tales como:
        Canal de YouTube, Instagram, Twitter, Facebook, Tik-Tock y a través
        nuestra página web: lotozulia-oficial.com.<br/>
        <br/>12. RESULTADOS: Es el número de (3) dígitos que abarca el cero (0) y
        el nueve (9), ambos inclusive del 000 al 999, en el estricto orden de
        extracción de derecha a izquierda, obtenida en un sorteo de lotería TRIPLE
        PELOTICA o TRIPLE PELOTA. Se puede decir también que es la sección de la
        plataforma, donde aparece reflejado los resultados de los Juegos de
        lotería TRIPLE PELOTICA o TRIPLE PELOTA, Para ellos, solo se debe ingresar
        a la plataforma, e ir a la sección RESULTADOS, del menú izquierdo, y al
        hacer clik, donde se podrá ver el historial de los sorteos e igualmente
        podrán visualizarse a través en la página web. YouTube, Facebook e
        Instagram, tik-tok y demás.<br/>
        <br/>13. MEDIOS DE APUESTAS: Representan las categorías bajo las cuales
        funcionan los diferentes juegos de Lotería, atendiendo a las reglas,
        términos y condiciones, de la Ley Nacional de Lotería y demás
        disposiciones legales.<br/>
        <br/>14. JUEGO DE LOTERÍA TRIPLE PELOTICA: Es el tipo de juego de lotería
        que permite al apostador seleccionar combinación de tres (3) dígitos que
        abarca el cero (0) y el nueve (9), ambos inclusive del 000 al 999, en el
        estricto orden de extracción de derecha a izquierda. <br/>
        <br/>15. JUEGO DE LOTERÍA TRIPLE PELOTA: Es el tipo de juego de lotería
        que permite al apostador seleccionar combinación de tres (3) dígitos que
        abarca el cero (0) y el nueve (9), ambos inclusive (del 000 al 999), más
        una pelota distintiva con una figura alusiva a una pelota deportiva.
        <br/>
        <br/>16. SIMBOLO: Es la representación de un objeto asociada a doce (12)
        tipos de Pelotas, alusivas un deporte tales como: Básquet, Fútbol,
        Béisbol, Golf, Fútbol Americano, Tenis, Pelota de Playa, Hockey, Billar,
        Voleibol, Bowling y Ping Pong).<br/>
        <br/>17. ESFERA: Son sólidos identificados de acuerdo con la figura, con
        números, letras y la figura alusiva a pelotas deportivas.<br/>

        <br/>18. SORTEOS: Son acto público mediante el cual se lleva a cabo la
        realización del juego de lotería.<br/>
        <br/>19. TICKETS: Es un boleto virtual o impreso en el centro de apuesta
        que cumple con todos los requisitos de un ticket de lotería. Que será
        expendido en los centros de apuestas autorizados, que estableces todas las
        normas de juegos aquí establecidas: A) TICKETS VIRTUAL: Es aquel cuyas
        combinaciones de números, figuras o signos, así como el monto de las
        apuestas, son seleccionados por el apostador a través de un medio
        electrónico, como telefonía móvil, computador conectado a internet, capta
        y validad a través de nuestra web su apuesta. B) TICKETS IMPRESO: Es aquel
        cuyas combinaciones de números, figuras signos, así como el monto de la
        apuesta son seleccionados por el apostador en el centro de apuesta, donde
        en el mismo se imprime cumpliendo este todas las especificaciones
        establecidas en la ley nacional de Lotería para el expendio de los
        mismos.<br/>

        <br/>20. SOPORTE TECNICO: Es la sección de ayuda, donde podrá contactar
        directamente con los teleoperadores soporte técnico, para aclarar todas
        las dudas, en cuanto a registro, procedimientos e historial de Jugadas, y
        cualquier otra incidencia que surja.<br/>
        <br/>21. HISTORIAL: Es la sección de la plataforma donde el Apostador,
        tendrá acceso y visualizarán, sus jugadas, los sorteos realizados y los
        premios recibidos.<br/>
        <br/>
        <center>
          <h5><b> CAPÍTULO III TÉRMINOS DE LA COMPRA </b></h5>
        </center>
        ARTÍCULO 4: Es imprescindible que el APOSTADOR al ingresar en la
        PLATAFORMA, manifieste haber leído y conforme acepte los presentes
        términos y condiciones, para ellos debe: Todo APOSTADOR de la presente
        PLATAFORMA, debe ser una persona natural, mayor de 18 años y con capacidad
        de obrar, donde deberá suministrar todos los datos de identificación a los
        fines de establecer un registro único e intransferible. Para registrarse
        el usuario deberá ingresa: www.lotozulia-oficial.com. Y seleccionar porque
        cuenta desea ingresar (Facebook, correo electrónico, o por el Google), y
        designar una contraseña, que la misma será utilizada cada vez que inicie
        sección. EL APOSTADOR podrá recuperar su contraseña, en caso de olvidar la
        misma se le enviará un correo a la dirección indicada, con un link, para
        resetear su contraseña o mediante de un Código de Verificación por MSM
        donde tendrá la opción de colocar una nueva contraseña. EL APOSTADOR
        registrado en la PLATAFORMA será el legítimo propietario del ticket
        virtual que compre a través de la PLATAFORMA, y el mismo no es
        transferible. Deberá llenar todos los extremos (Código del Banco, Numero
        de celular y, N° de Cedula), para afiliar su pago móvil a la plataforma.
        Ya que todos los pagos se realizan a través de la opción descrita: tu
        saldo, asociada al pago móvil, y darle aceptar a los términos y
        condiciones aquí descritos. Unas realizado exitosamente el registro,
        recibirá un pago móvil de 0,01 bs. Para confirmar que los datos son
        correctos. Una vez ya confirmados recibirá 1$ de obsequio, para realizar
        tu primera jugada. El monto que se cargue por pago móvil debe ser en
        Bolívares Digitales, el mismo será transformado en dólares, usando el
        cambio a la tasa del banco Central de Venezuela, el cual será reflejado de
        forma automática en la plataforma. Si requieres ayuda, debes ir a la
        sección de ingresar dinero y seguir las instrucciones. Para jugar, EL
        APOSTADOR debe ingresar en el menú al lado izquierdo de la plataforma y
        seleccionarla modalidad de juego que desea jugar, con sus respectivos
        montos, seleccionar sus combinaciones por jugadas, confirman su compra y
        esperar que el sistema le genere su ticket de compra. Una vez realizada la
        compra del ticket y completado el proceso satisfactoriamente, aceptado el
        pago y autorizado el débito de la cuenta del EL APOSTADOR, no se aceptan
        devoluciones de la compra ni reclamos sobre posibles premios que pudieran
        favorecer al EL APOSTADOR, cuya compra no se haya completado
        satisfactoriamente. Pasado unos minutos de la transacción realizada, se
        reflejará un balance de los fondos con los cual podrás jugar en cualquiera
        de las modalidades de juegos que te ofrece la plataforma. EL APOSTADOR
        podrá efectuar la compra de los tickets todos los días, con excepción de
        los días Feriados y los que estime la operadora por situaciones de caso
        fortuito o fuerza mayor. LA OPERADORA estipula el cierre de venta, 30 min
        antes de cada sorteo. EL APOSTADOR que resulte ganador, se obliga a
        identificarse con su respectivo documento de identidad, y a presentarse u
        someterse a publicidad de la operadora gratuitamente, cuando ella así lo
        requiera. CAPÍTULO IV DESCRIPCIÓN DE LOS TIPOS DE SORTEOS ARTÍCULO 5: LA
        OPERADORA ofrece al público general, sin menoscabo de cambios futuros,
        (que deberán ser debidamente notificados a nuestros APOSTADORES a través
        de la PLATAFORMA), los siguientes tipos de sorteos: a). TRIPLE PELOTICA:
        El juego de lotería “TRIPLE PELOTICA”, es un juego tipo triple y terminal
        que consiste en: TRIPLE PELOTICA: El Apostador deberá seleccionar
        combinación de tres (3) dígitos que abarca del cero (0) al nueve (9),
        ambos inclusive, es decir, del 000 al 999, en estricto orden de extracción
        de izquierda a derecha.. TERMINAL PELOTICA: El Apostador deberá
        seleccionar combinación de dos (2) dígitos que abarca del cero (0) al
        nueve (9), ambos e inclusive, es decir, del 00 al 99, en estricto orden de
        extracción de izquierda a derecha. b)- TRIPLE PELOTA: Es tipo de Juego de
        lotería donde el usuario selecciona un número de tres dígitos entre el 000
        y el 999 más una figura alusiva a una pelota deportiva. La premiación se
        realiza con el acierto de 4 esféricas de izquierda a derecha en orden de
        extracción (3 números + la pelota), Teniendo 12 tipos de figuras de
        Pelotas Deportivas (Básquet, Fútbol, Béisbol, Golf, Fútbol Americano,
        Tenis, Hockey, Billar, Voleibol, Bolos y Pimpón). ARTÍCULO 6: SORTEOS: los
        solteros de los juegos de lotería, serán mediante de máquinas movidas por
        extracción de aire, de izquierda a derecha, en el estricto orden de
        extracción, en presencia de un notario público, quien levantar y firmará
        un acta de los sorteos dando fe pública de los mismos. Estos serán
        transmitidos vía YOUTUBE y por los diferentes medios de comunicación
        social (Instagram, Twitter, Facebook, Tik-Tock y a través nuestra página
        web: lotozulia-oficial.com). En el caso de que alguno de los sorteos no
        pueda realizarse por causa sobrevenida de fuerza mayor o caso fortuito, o
        deba interrumpirse durante el curso de su ejecución, su celebración o
        continuación se realizará cuando cesen dichas circunstancias. Concluido el
        sorteo, se dejará constancia de su resultado en el ACTA respectiva que
        será firmada por el Notario, por el representante de la LOTERÍA DEL ZULIA
        y por el representante de la OPERADORA. En caso de ausencia del
        representante de la LOTERIA DEL ZULIA O DE LA OPERADORA, firmarán el ACTA
        dos (2) personas escogidas entre las asistentes como testigos del acto.
        ARTÍCULO 7: PREMIOS: PARA LA CANCELACIÓN DE PREMIOS: Solamente
        participarán en el sorteo respectivo los tickets-recibos de los Juegos,
        emitidos por nuestra plataforma que tengan el CODIGO DE VALIDACION, que
        establece la Providencia Administrativa N.º 2009-0040 publicada en la
        Gaceta Oficial de la República Bolivariana de Venezuela número: 39.222 de
        fecha 16 de Julio de 2009. No tendrán validez los ticket-recibos, dudosos,
        cuyo Código de validación no registres en nuestra plataforma. que no
        permitan su clara identificación, ni los que presenten enmiendas, roturas,
        adulteraciones, alteraciones o signos no autorizados, ni los que se
        presenten incompletos. Tampoco tendrán validez el ticket-recibo los que no
        estén registrados en el sistema de apuestas de la Operadora.
        CARACTERISTICA DEL TICKET O BOLETO ARTÍCULO 8: El ticket de los juegos de
        Lotería TRIPLE PELOTA y TRIPLE PELOTICA, debe contener las
        especificaciones técnicas siguientes: a)Logotipo y nombre de la Lotería
        (LOTERIA DEL ZULIA). b)Tipo de sorteo: TRIPLE PELOTA O TRIPLE PELOTICA
        c)Serial del sorteo: d)Serial del ticket e)Fecha y hora de la compra del
        ticket f)Fecha y hora del Sorteo g) Nombre del APOSTADOR y Rif. h)
        Combinación, monto de la jugada, total de precio a pagar. i) Código de
        validación Qr. ARTÍCULO 9: EL PAGO DE LOS PREMIOS: DEL DERECHO A COBRAR Y
        LA CADUCIDAD: Los premios, se le confiere al APOSTADOR GANADOR, y LA
        OPERADORA garantiza el pago de su premio dentro de las 24 horas contadas a
        partir del sorteo del número donde resulte ganador del mismo, donde el
        Apostador tendrá tres (03) días hábiles contados desde momento que su
        ticket resulte ganador para retirar su ganancia por taquilla. En caso de
        reclamos de premios, estos caducarán a los quince (15) días continuos
        siguientes contados a partir de la fecha del sorteo a que corresponda el
        número ganador o ganadores. Este lapso podrá ser modificado por la
        OPERADORA Y POR EL INSTITUTO RENTA DE BENEFICIENCIA PÚBLICA Y DE
        ASISTENCIA SOCIAL DEL ESTADO ZULIA (LOTERIA DE ZULIA) "IOBPAS", el cual
        debe ser comunicado a través a un medio de circulación nacional e
        informado con antelación a la Comisión Nacional de Lotería (CONALOT).
        VALOR Y TIPO DE LA MONEDA PARA EL PAGA DE LA APUESTA ARTÍCULO 10: LA
        OPERADORA queda ampliamente facultada para establecer el costo del medio
        de apuesta, que evidencie la apuesta pactada y garantice el pago de los
        premios que hubiere lugar. El monto mínimo para los juegos de lotería
        "TRIPLE PELOTA O TRIPLE PELOTICA" será definido dependiendo de las
        exigencias del mercado previa aprobación de la EMPRESA OPERADORA (ZUAZAR
        3000 C.A). Y DEL INSTITUTO RENTA DE BENEFICENCIA PÚBLICA Y DE ASISTENCIA
        SOCIAL DEL ESTADO ZULIA "LOTERÍA DEL ZULIA" (IOBPAS). El valor del medio
        de apuesta será un (1) dólar o su equivalente en bolívares según la tasa
        del Banco Central de Venezuela. CAPÍTULO V GESTIÓN DE LA CUENTA DEL
        USUARIO ARTÍCULO 11: EL SALDO: Una vez cargado en la plataforma los datos
        a nombre del APOSTADOR y su contraseña, este podrá visualizar en la
        sección: tu saldo, donde podrá administrar el saldo disponible, que podrá
        ser utilizado para pagar los juegos que le ofrece la plataforma. ARTÍCULO
        12: DEL ORIGEN DE LOS FONDOS PARA JUGAR: Los centros de apuestas o
        comercializadoras una vez Culminado el registro en nuestra plataforma,
        está sujeto a todos los términos y condiciones, aquí establecido, por
        ende, LA OPERADORA en el estricto cumplimiento de las leyes,
        específicamente la PROVIDENCIA ADMINISTRATIVA N°/DP/2016-0029 y LEY
        ORGÁNICA CONTRA LA DELINCUENCIA ORGANIZADA Y FINANCIAMIENTO AL TERRORISMO,
        Mediante el cual se establecen las normas de prevención, control y
        fiscalización de los delitos de legitimación de capitales y financiamiento
        al terrorismo, en la actividad de juegos de lotería. no se hace
        responsable por el origen de los fondos de los apostadores, e insta a los
        mismo a cumplir con los ordenamientos jurídicos vigentes, que regula la
        materia. ARTICULO 13: HISTÓRIAL DE LAS OPERACIONES: En la plataforma EL
        APOSTADOR tendrá TRES (03) tipos de historial: a)- HISTORIAL DE LAS
        JUGADAS: EL APOSTADOR podrá tener acceso y visualizar todas las jugadas.
        b) HISTORIAL DE LOS SORTEOS; EL APOSTADOR podrá acceder y visualizar todos
        los sorteos realizados. c)- HISTORIAL DE FONDOS PARA JUGAR: Donde podrá
        ver el historial de los pagos móviles que ha usado para recargar su saldo
        y lo movimientos de compra y retiros de fondos de la plataforma. ARTICULO
        14: AÑADIR SALDO DESDE TU PAGO MOVIL: A través de la sección TU SALDO, EL
        APOSTADOR podrá ingresar mediante el uso de su Pago Móvil, el saldo
        requerido para realizar las operaciones de compra de los tickets para los
        juegos de lotería. ARTICULO 15: RETIRAR FONDOS: EL APOSTADOR puede retirar
        el saldo transferible de la sección tu saldo, únicamente a la cuenta
        bancaria que ha sido registrada en la PLATAFORMA por el propio EL
        APOSTADOR. ARTICULO 16: DE LA PUBLICIDAD: El APOSTADOR GANADOR de un
        premio, queda Obligado a someterse a publicidad de la operadora
        gratuitamente, cuando ella así lo requiera, el pago del premio quedara
        suspendido, hasta tanto el APOSTADOR GANADOR, allá cumplido con su
        compromiso publicitario. CAPÍTULO VI DE LOS RECLAMOS ARTICULO 17: El
        público apostador, que se consideren con derecho a reclamo podrán hacerlo,
        de las siguiente maneras, a través: 1).- De la plataforma, en la opción
        preguntas frecuentes de los usuarios, 2).- Comunicándose a través de
        nuestros números 0412 9095901 / 9095911/ 0261-793.71.06 quienes serán
        atendidos por nuestros personal de soporte de call-cente, que resolverán
        todas sus inquietudes y reclamos, 3).- Dirigiéndose a nuestra oficina
        comercial ubicada en su sede fiscal, en la Ciudad de Maracaibo: Calle 77
        Entre Avenidas 3y Y 3h, Edificio Villa Ota, Piso 4,Oficinas 4-1 Y 4-2,
        Maracaibo Del Estado Zulia. Toda reclamación deberá formularse de lunes a
        viernes, de 9 AM a 11 AM, dentro del plazo máximo e improrrogable de
        quince (15) días contados a partir del día siguiente a la fecha del sorteo
        correspondiente, el cual deberá llenar los siguientes extremos: cédula de
        identidad laminada o pasaporte, ser el titular de una cuenta en nuestra
        plataforma o ser el titular ganador de un ticket, debe acompañar su
        reclamo de una carta de exposición de motivo, donde exponga el motivo de
        su reclamo y haber agotado las dos primeras opciones para realizar
        reclamos. ARTICULO 18: La Operadora se reserva el derecho de iniciar la
        acción penal correspondiente en caso de que se presuma que el ticket
        presentado al cobro o sometido a reclamo haya sufrido alguna alteración o
        falsificación, y que el mismo no haya sido emitido por nuestra plataforma
        Autorizada. La Operadora y la Junta de Beneficencia Pública y Social del
        Estado Zulia (Lotería de Zulia) no asumirán responsabilidad alguna en caso
        de error en los datos registrados en el formulario de reclamación, y
        Cualquier demanda judicial deberá ser incoarse únicamente contra LA
        OPERADORA, y sólo por ante los Tribunales de la ciudad de Caracas,
        Distrito Capital, con exclusión de cualesquiera otros. ARTÍCULO 19: La
        Operadora, advierte al público Apostador y los agentes Autorizados para el
        expendio del producto de Lotería, que el desuso de nuestra plataforma por
        más de noventa (90) días continuos, generan bloqueo del mismo, por los que
        para su reactivación deberán solicitarla a de nuestros personal de soporte
        técnico, a través de nuestra página web: www.lotozulia-oficial.com, y
        números de contactos: 0412 9095901 / 9095911/ 0261-793.71.06, con nuestro
        personal de call-center. PROHIBICIONES ARTÍCULO 20: Queda estrictamente
        prohibido, so pena de nulidad y por no tener capacidad negocial plena, los
        menores de dieciocho (18) años, quienes no podrán adquirir tickets del
        juego de lotería TRIPLE PELOTA o TRIPLE PELOTICA tal y como lo prevé los
        ARTÍCULOS 92 y 229 de LA LEY ORGÁNICA PARA LA PROTECCIÓN DE NIÑOS, NIÑAS Y
        ADOLESCENTES (LOPNNA). En consecuencia, tampoco podrán participar como
        apostadores ni cobrar premios. JUEGO RESPONSABLE ARTICULO 21: LA OPERADORA
        y EL INSTITUTO RENTA DE BENEFICENCIA PÚBLICA Y DE ASISTENCIA SOCIAL DEL
        ESTADO ZULIA "(LOTERÍA DE ZULIA) IOBPAS." En el marco de sus políticas de
        protección al público apostador, a los niños, niñas y adolescente y a
        otros colectivos vulnerables, insta a su público apostador a realizar sus
        apuestas de manera responsables, y consciente, no incurriendo en
        adicciones o infracciones del ordenamiento jurídico vigente. ARTICULO 22:
        LA OPERADORA y EL INSTITUTO RENTA DE BENEFICENCIA PÚBLICA Y DE ASISTENCIA
        SOCIAL DEL ESTADO ZULIA "(LOTERÍA DE ZULIA) IOBPAS." Dispone de un Comité
        de Prevención y Control de Legitimación de Capitales y Financiamiento al
        Terrorismo de la OPERADORA, y será el responsable de la prevención,
        control y detección de operaciones sospechosas, identificando toda
        información relativa a las operaciones o hechos que pueden estar
        relacionados con este delito, a fin de coordinar las medidas preventivas y
        de control de las posibles operaciones relacionadas con posibles Delitos
        de la Legitimación de Capitales y Financiamiento al Terrorismo y
        poniéndolo a la orden de los organismos de administración de justicia del
        Estado. ARTICULO 23: LA OPERADORA y EL INSTITUTO RENTA DE BENEFICENCIA
        PÚBLICA Y DE ASISTENCIA SOCIAL DEL ESTADO ZULIA "(LOTERÍA DE ZULIA)
        IOBPAS" , en virtud de dar cumplimiento a los establecido en la nuestra
        carta magna y en las demás disposiciones legales que regulan la protección
        integral de los sistemas tecnológicos (ley contra delitos informático),
        garantiza al público apostador y centros de apuestas (taquilla), el
        resguardo de su información así como también, el correcto manejos de las
        operaciones de venta y atención a los apostadores, sin que de ellos se
        generen ningún ilícitos tipificado en la mismas, todo esto en concordancia
        a lo previsto en el artículo 28 de la constitución de la República
        Bolivariana de Venezuela. CAPÍTULO VII DE LOS FONDOS DE LA OPERADORA
        ARTICULO 24: La OPERADORA mediante el presente instrumento jurídico
        declara bajo fe de juramento, que los capitales, bienes, haberes, valores,
        títulos o actos jurídicos, que nuestra empresa ha constituido, proceden de
        actividades licitas, lo cual pueden ser corroborados por los organismos
        competente, y los mismos no tienen relación alguna con sumas de dinero,
        capitales, bienes, haberes y valores o títulos que se consideren productos
        de actividades, ilícitas contemplada en la ley Especial Contra los Delitos
        Informáticos, Providencia N° NL/DP/2016-0029 sobre las Normas de
        Prevención, Control y Fiscalización de los Delitos de Legitimación de
        Capitales y el Financiamiento al Terrorismo en la Actividad de los Juegos
        de Lotería, Providencia Administrativa N.º 2009-0040 publicada en la
        Gaceta Oficial de la República Bolivariana de Venezuela número: 39.222 de
        fecha 16 de Julio de 2009, Ley Orgánica Contra la Delincuencia Organizada
        y el Financiamiento al Terrorismo y/o en la ley Orgánica de Drogas.
        CAPÍTULO VIII DISPOSICIONES FINALES CLÁUSULA DE ADHESIÓN ARTICULO 25: El
        hecho LOS APOSTADORES de participar juegos de lotería TRIPLE PELOTA y
        TRIPLE PELOTICA implica, por parte, su aceptación y su adhesión a las
        normas previstas en el vigente en estos términos y condiciones del
        producto de lotería. ARTICULO 26: DISPOSICIONES FINALES: La Operadora,
        previa aprobación de la Junta de Beneficencia Pública y Social del Estado
        Zulia (Lotería de Zulia), podrá modificar total o parcialmente este
        ordenamiento jurídico y lo informará oportunamente al público y el
        presente entrará en vigor a partir de la fecha de su publicación. Zuazar
        3000 C.A. Por la Operadora JUNTA DE BENEFICENCIA PÚBLICA Y SOCIAL DEL
        ESTADO ZULIA (LOTERIA DEL ZULIA). - Por el Instituto
      </ScrollPanel>
    </div>
  </div>
</template>

<style lang="scss" scoped>

@media (max-width: 991px) {
  #scroll {
width: 100%;
max-height: 420px;

  }
  #cardoverflow {
overflow: scroll;

  }

}
</style>
