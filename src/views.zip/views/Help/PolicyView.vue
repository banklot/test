<script setup lang="ts">
import ScrollPanel from "primevue/scrollpanel";

</script>

<template>
  <div class="card">

    <div class="windowTitle">Políticas de Privacidad</div>

    <div class="text-justify flex justify-content-center mt-4">
    <ScrollPanel class="scrollPanel" id="scroll">

        <b> ZUAZAR 3000 C.A.,</b> a través <b>EL INSTITUTO RENTA DE BENEFICENCIA PÚBLICA Y DE ASISTENCIA SOCIAL DEL
        ESTADO ZULIA (LOTERÍA DEL ZULIA) IOBPAS,</b> ofrece al público apostador una amplia
        gama de juegos de lotería, con un sistema novedoso a través de una plataforma moderna, versátil y rápida, que le
        garantiza el nivel de sus apuestas, a demás de incursionar en nuestro país
        con un sistema de juegos de lotería on line, que le permite al usuario realizar sus apuestas a desde la
        comodidad de su dispositivo móvil o a través de su taquilla de preferencia.<br>
        • Su privacidad es importante para nosotros, por eso esta declaración de privacidad explica, cuales los datos
        personales que se recopilan en la plataforma on line y su uso, con la finalidad
        de garantizarle una seguridad jurídica en el sistema de apuestas.<br>
        <br>• Mejorar, desarrollar y personalizar su compra, lo que nos permite tener contacto directo, para promocionar
        nuestro producto de lotería y realizar las transacciones que solicite.
        También usamos los datos, para operar en nuestro negocio, lo que incluye analizar nuestro rendimiento, para
        cumplir con nuestras obligaciones legales, para desarrollar nuestra capacidad de trabajo.<br>
        • Nuestro compromiso con la privacidad de nuestros usuarios. Nos comprometemos a proteger la privacidad de
        nuestros usuarios, siendo una de nuestras principales prioridades la privacidad de nuestros visitantes. Este
        documento de Política de privacidad contiene los tipos de información que la Lotería recopila y registra y
        explicamos cómo la usamos. La Política de Privacidad de la Lotería del Zulia, es aplicable a toda la información
        personal recolectada por nosotros, o remitida a nosotros, ya sea con conexión o sin conexión, incluyendo
        información personal recolectada o remitida a través de nuestros sitios web y cualquier sitio móvil, aplicación,
        widget y cualquier otra modalidad interactiva móvil, a través de las páginas de redes sociales oficiales que
        controlamos, así como a través de mensajes de correo electrónico con formato HTML que enviemos. Esta política no
        se aplica a ninguna información recopilada fuera de línea o a través de canales que no sean este sitio web.<br>
        <br>
        <center><h5><b>CONSENTIMIENTO</b></h5></center>
        Al utilizar nuestro sitio web, usted acepta nuestra Política de Privacidad y acepta sus términos. Si usted no
        está de acuerdo con alguno de los términos de esta Política de Privacidad, por favor no utilice la página ni
        proporcione ningún tipo de información personal.
        <br>
        <center><h5><b>TIPO DE INFORMACIÓN PERSONAL QUE SOLICITAMOS</b></h5></center>
        Toda información personal que se le solicita a nuestros usuarios y las razones por las que se le solicita, serán
        aclaradas en el momento en que le sea solicitada.
        La Información personal a efectos de la presente política es considerada como aquella información que es
        utilizada para la creación de un perfil de los usuarios, tales como: <br><br>
        • Nombre y apellido<br>
        • Nombre de usuario para el login<br>
        • Cédula de identidad o número de pasaporte<br>
        • Datos bancarios para retiro de dinero<br>
        • Número telefónico de celular<br>
        • Correo electrónico<br>
        • Domicilio (incluyendo direcciones de facturación y de envío)<br>
        • Número de tarjeta de crédito y débito<br>
        • Foto de perfil<br>
        • Identificación de Usuario de Redes Sociales<br>
        • Información de su navegador y dispositivo<br>
        • Información del archivo de registro del servidor<br>
        • Información recolectada a través de cookies, etiquetas de píxeles y otras tecnologías<br>
        • Datos para el uso de las aplicaciones<br>
        • Información demográfica y otra información proporcionada por usted<br>
        • Información de localización<br>
        • Información agregada<br><br>
        <center><h5><b>MANERA DE RECOLECTAR LA INFORMACIÓN</b></h5></center>
        Si se comunica con nosotros directamente, probablemente obtendremos información adicional sobre usted, tales
        como nombre, dirección de correo electrónico, número de teléfono, contenido de su mensaje, archivos adjuntos
        enviados por usted, y toda aquella información que decida proporcionar, sin necesidad de conexión.
        Así mismo, podremos recopilar su información personal a través de los sitios web, o de otras fuentes como datos
        públicos, plataformas de redes sociales, de personas con las que usted sea amigo o se encuentre conectado de
        alguna otra forma en plataformas de redes sociales, así como de cualquier tercero, a través de su navegador o
        dispositivo, siendo esta información para fines estadísticos, así como para garantizar el correcto
        funcionamiento de los Sitios.
        De igual forma, podemos recolectar información a través de archivos de registro del servidor, tal como la
        "Dirección IP" la cual es identificada y registrada automáticamente en nuestros archivos de registro del
        servidor cuando el usuario visita el sitio, quedando registrado además la hora de la visita páginas visitadas.
        A través de las cookies, es posible que un servidor web pueda transferir datos con fines de registro y otros
        propósitos, sin embargo, si el usuario no desea que su información sea recolectada a través del uso de cookies,
        es posible siempre decidir deshabilitar las mismas.
        Al descargar y utilizar una Aplicación, es posible rastrear y recopilar datos de uso de la Aplicación, tales
        como la fecha y hora en que la Aplicación es instalada en el dispositivo del usuario acceda a nuestros
        servidores y qué información y archivos han sido descargados a la Aplicación en su número de dispositivo.
        USO QUE LE DAREMOS A LA INFORMACIÓN PERSONAL DE NUESTROS USUARIOS
        • Con la finalidad de mejorar, personalizar y actualizar nuestro sitio.
        • Para poder dar respuesta a las preguntas, solicitudes y comentarios de nuestros usuarios.
        • En el caso de posibles cambios de nuestras políticas, términos y condiciones, sin embargo, esta opción siempre
        podrá ser no aceptada por nuestros clientes.
        • Con la finalidad de complementar las solicitudes de compra de tickets solicitudes de participación en las
        diversas modalidades de juego, tratamiento de los pagos realizados, entrega de premios, así como para
        comunicarnos con nuestros clientes para aclarar cualquier duda acerca de las compras realizadas y proporcionar
        la información necesaria sobre ello.
        • Para el envío de invitaciones para participar en eventos especiales, difundir información sobre productos y
        promociones, siempre y cuando ello sea aceptado previamente por nuestros usuarios.
        • Para la participación en foros, chats informativos y otros medios en donde nuestros usuarios decidan
        participar.
        • Con fines de análisis de mercado, desarrollos de nuevas opciones de juegos y apuestas, mejora del sitio web,
        tendencias de uso, optimización de la eficacia en las campañas de publicidad, tendencias de uso y mediciones de
        satisfacción de los usuarios.
        • Con fines estadísticos y con perspectiva de mejoras y de nuevos desarrollos de actividades en nuestro sitio
        web utilizamos aquella información que ha sido recopilada a través del navegador.
        • Para ofrecer a nuestros usuarios servicios personalizados de acuerdo a su ubicación podríamos utilizar la
        localización física del dispositivo usado.
        • En cumplimiento de la legislación venezolana en materia de protección de la información personal incluyendo
        semejantes en otros países, para cumplir con requerimientos de instancias judiciales en procesos penales, para
        dar respuesta a solicitudes de autoridades públicas debidamente facultadas para ello.
        • Así mismo, para hacer cumplir los contenidos de nuestros términos y condiciones, protección de nuestros
        derechos, privacidad, seguridad o propiedad intelectual.
        ADVERTENCIA RELACIONADA A LA SEGURIDAD
        Es preciso que nuestros usuarios conozcan que ninguna transmisión de datos a través de internet o a través del
        sistema de almacenamiento de datos es 100 % segura, sin embargo, usamos todas las medidas técnicas internas, así
        como organizacionales con el firme propósito que la información de nuestros usuarios y bajo nuestro conocimiento
        sea protegida.
        Nuestros usuarios tienen la posibilidad real en casos de creer que sus datos y que su comunicación con nosotros
        no se encuentra lo suficientemente segura de notificarnos cualquier incidente a través de nuestras vías de
        contacto.
        ARCHIVOS DE REGISTRO
        La Lotería sigue un procedimiento estándar de uso de archivos de registro, registrando a los usuarios cuando
        visitan los sitios web. La información recopilada por los archivos de registro incluye el tipo de navegador,
        direcciones de protocolo de internet (IP), proveedor de servicios de Internet (ISP), marca de fecha y hora, así
        como páginas de referencia.
        OPCIONES RELACIONADAS AL USO Y ACCESO
        • Nuestros usuarios pueden a través de diversos medios cancelar suscripciones a efectos de dejar de recibir
        publicidad y comunicaciones emitidas por nosotros, y a tal fin es preciso manifestar su interés inequívoco de
        dejar de recibir las mismas.
        • Nunca revelaremos la información de nuestros usuarios a terceros con ningún fin dentro de los términos legales
        que rigen la materia, a menos que seamos autorizados para ello explícitamente. De igual forma, y en este
        sentido, los usuarios que hayan convenido en permitir que su información sea compartida con terceros, pueden en
        cualquier momento solicitarnos que la transmisión de su información sea cancelada.
        • Toda solicitud relacionada al cese de la recepción de publicidad y de transmisión de información será
        procesada de la manera más expedita posible, siendo resuelta a más tardar en 30 días continuos contados a partir
        de la solicitud efectuada por el usuario.
        • Con la finalidad de actualizar, corregir, suprimir o limitar de cualquier manera el uso de la Información
        Personal suministrada por los usuarios es preciso utilizar las vías de contacto que a tal fin se han dispuesto
        en nuestra página, especificando con detalle la información personal que debe ser actualizada, corregida,
        suprimida o limitada.
        • Por solicitud derivada de normas relacionadas a la materia de juegos de envite y azar, es posible que cierta
        información personal deba ser conservada en nuestras bases de datos, bien sea para finalizar transacciones o
        rendir cuentas de las mismas.
        RESPONSABILIDAD CON RESPECTO A SITIOS DE TERCEROS
        Esta Política de Privacidad no alcanza a las políticas de privacidad o práctica de terceros que operen en sitios
        enlazados con el nuestro. La inclusión de un enlace en nuestro sitio no implica de modo alguno que el sitio
        enlazado cuente con verificación o rectificación nuestra, por ende, no tenemos ningún control ni nos haremos
        responsables por el uso de la información que los usuarios proporcionen a cualquier tercero a través del uso de
        estas funciones.
        En nuestro sitio es posible darle acceso a funciones de terceros que permiten enviar contenido a cuentas de
        redes sociales de terceros; en este sentido, cualquier información que se proporcione a través de estas
        funciones se rigen por la política de privacidad de estos terceros.
        Adicionalmente, nosotros no somos responsables con respecto a las prácticas establecidas por organizaciones
        tales como Facebook, Google, Microsoft y cualquier otro desarrollador de aplicaciones, proveedor de plataformas,
        etc en cuanto a sus políticas de recolección, y uso de datos personales.
        TIEMPO DE PRESERVACIÓN
        De conformidad con el ordenamiento jurídico venezolano, conservamos la información personal de nuestros clientes
        por el lapso de tiempo necesario para cumplir con la obligación derivada de los juegos de envite y azar, además
        de cumplir con los propósitos establecidos en la presente Política de Privacidad.
        USO DE LOS SITIOS POR MENORES DE EDAD
        Nuestro sitio está destinado a ser utilizado por personas mayores de edad únicamente y por ende, se solicita el
        suministro de datos relacionados a la edad de los usuarios para su registro.
        INFORMACIÓN SENSIBLE
        Nunca solicitaremos información que pueda resultar ser sensible para nuestros usuarios, tales como orientación
        sexual, información relacionada con el origen racial o étnico, inclinaciones políticas, religión u otras
        creencias, salud, dolencias, antecedentes penales.
        USO DE LAS COOKIES
        Las cookies utilizadas por nuestro sitio web sirven para almacenar información, incluidas las preferencias de
        nuestros visitantes y páginas del sitio a las que el usuario accedió. Se utiliza dicha información con la única
        intención de optimizar la experiencia de los usuarios al personalizar el contenido de nuestra página web.
      </ScrollPanel>
    </div>
  </div>
</template>

<style scoped>
@media (max-width: 991px) {
  #scroll {
width: 100%;
max-height: 420px;

  }
  #cardoverflow {
overflow: scroll;

  }

}
</style>
