<script setup lang="ts">

</script>

<template>
  <div class="card">
    <div class="windowTitle">Contáctanos</div>

    <div class="grid mt-8 mb-8">
      <div class="col">
        <div style="text-align: center;">
          <img
              src="/images/callcenter.png"
              alt=""
              class="logo"
              width="100"
          />
        </div>
        <br/>
        <br/>
        <div class="text">
          TELÉFONO<br>
          Horas de Atención<br>
          (Lunes a Viernes, 9am am 5pm)<br>
          xxx-xxx-xxxx
        </div>
      </div>
      <div class="col">
        <div style="text-align: center;">
          <img
              src="/images/email.png"
              alt=""
              class="logo"
              width="100"
          />
        </div>
        <br/>
        <br/>
        <div class="text">
          CORREO ELECTRONICO
          <br/>info@banklot.com
        </div>
      </div>
      <div class="col">
        <div style="text-align: center;">
          <img
              src="/images/whatsapp.png"
              alt=""
              class="logo"
              width="100"
          />
        </div>
        <br/>
        <br/>
        <div class="text"> CHAT EN VIVO
        </div>
      </div>
    </div>
  </div>
</template>

<style>
.text {
  color: #2d2e82;
  font-weight: bold;
  text-align: center;
}
</style>
